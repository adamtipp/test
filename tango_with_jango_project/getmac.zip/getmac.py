import sys
import pickle
import random


def main():

    mac = ''

    with open('macs.pkl') as infile:
        macs = pickle.load(infile)
        mac = macs[random.randrange(0,len(macs)-1)]

    sys.stdout.write(str(mac))


if __name__ == "__main__":
    main()